    function handleSubmit(){
        const name = document.getElementById('fname').value;
        const dob = document.getElementById('dob').value;
        const email = document.getElementById('p_email').value;
        const mobile = document.getElementById('mob').value;
        const gender = document.getElementById('gen').value;
        const occupation = document.getElementById('occ').value;
        const idType = document.getElementById('id_type').value;
        const idNo = document.getElementById('id_no').value;
        const issueAuthority = document.getElementById('id_iss_auth').value;
        const issueDate = document.getElementById('id_iss_date').value;
        const issueSate = document.getElementById('id_iss_state').value;
        const expDate = document.getElementById('id_exp_date').value;

        localStorage.setItem("name",name);
        localStorage.setItem("dob",dob);
        localStorage.setItem("email",email);
        localStorage.setItem("mobile",mobile);
        localStorage.setItem("gender",gender);
        localStorage.setItem("occupation",occupation);
        localStorage.setItem("idType",idType);
        localStorage.setItem("idNo",idNo);
        localStorage.setItem("issueAuthority",issueAuthority);
        localStorage.setItem("issueDate",issueDate);
        localStorage.setItem("issueSate",issueSate);
        localStorage.setItem("expDate",expDate);
        
       // window.location.href ="result.html"
        return;
    }