    window.addEventListener('load', () => {

            
        const name = localStorage.getItem("name");
        const dob = localStorage.getItem("dob");
        const email = localStorage.getItem("email");
        const mobile =  localStorage.getItem("mobile");
        const gender = localStorage.getItem("gender");
        const occupation = localStorage.getItem("occupation");
        const idType = localStorage.getItem("idType");
        const idNo = localStorage.getItem("idNo");
        const issueAuthority = localStorage.getItem("issueAuthority");
        const issueDate = localStorage.getItem("issueDate");
        const issueSate = localStorage.getItem("issueSate");
        const expDate = localStorage.getItem("expDate");
    
        
        document.getElementById('fname').innerHTML = name;
        document.getElementById('dob').innerHTML = dob;
        document.getElementById('p_email').innerHTML = email;
        document.getElementById('mob').innerHTML = mobile;
        document.getElementById('gen').innerHTML = gender;
        document.getElementById('occ').innerHTML = occupation;
        document.getElementById('id_type').innerHTML = idType;
        document.getElementById('id_no').innerHTML = idNo;
        document.getElementById('id_iss_auth').innerHTML = issueAuthority;
        document.getElementById('id_iss_date').innerHTML = issueDate;
        document.getElementById('id_iss_state').innerHTML = issueSate;
        document.getElementById('id_exp_date').innerHTML = expDate;


    })