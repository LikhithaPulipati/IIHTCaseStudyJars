package com.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LambdaArrayListsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LambdaArrayListsApplication.class, args);

		Course course1 = new Course(1, "SSC", "Akhil", 12, 100000);
		Course course2 = new Course(2, "Inter", "Bindhu", 12, 250000);
		Course course3 = new Course(3, "Diploma", "Neha", 24, 300000);
		Course course4 = new Course(4, "B.tech", "Divya", 15, 1500000);
		Course course5 = new Course(5, "B.Pharm", "Faima", 15, 180000);
		Course course6 = new Course(6, "GRE", "Mouni", 15, 80000);
		Course course7 = new Course(7, "IELTS", "Sailu", 15, 120000);
		Course course8 = new Course(8, "CAT", "Siri", 15, 100000);
		Course course9 = new Course(9, "JEE", "Likhi", 15, 350000);
		Course course11 = new Course(10, "NEET", "Nikhil", 24, 100000);
		Course course10 = new Course(11, "B.Arch", "Keerthi", 15, 400000);
		Course course12 = new Course(12, "UPSC", "Charitha", 15, 100000);
		Course course13 = new Course(13, "IES", "Hari", 15, 1000000);
		Course course14 = new Course(14, "CLAT", "Abhi", 24, 1500000);
		Course course15 = new Course(15, "CDS", "Gopal", 36, 400000);

		List<Course> courseLists = Arrays.asList(course1, course2, course3, course4, course5, course6, course7, course8,
				course9, course10, course11, course12, course13, course14, course15);

		Comparator<Course> feeComparator = (c1, c2) -> (int) (c1.getTotal_fees() - c2.getTotal_fees());
		Comparator<Course> durationComparator = (c1, c2) -> (int) (c1.getCourse_duration() - c2.getCourse_duration());

		courseLists.sort(Collections.reverseOrder(feeComparator).thenComparing(durationComparator));

		//System.out.println(courseLists);
		courseLists.forEach(System.out::println);
	}

}
