package com.example;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.example.Calculator;

class CalciTest {

	@Test
	public void test() {
		assertEquals(2, Calculator.division(8, 4));
	}

	@Test
	@DisplayName("Division by zero should throw an ArithmeticException")
	void divideByZero() {
		Exception exception = assertThrows(ArithmeticException.class, () -> Calculator.division(1, 0));
		assertEquals("number cannot be divided by 0", exception.getMessage());
	}
}
